=== MyKavo - Website Change Monitoring ===
Contributors: dakshu007
Tags: monitoring, change detection, seo, uptime, screenshots
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Know when an update breaks your site. MyKavo checks your pages after every plugin, theme and WordPress update. Zero front-end impact.

== Description ==

Updates are the number one way WordPress sites break. A plugin, theme or WordPress update - often an automatic one, overnight - quietly changes a layout, removes a checkout button or sets a page to "noindex". Usually a customer notices before you do, and nobody knows which update did it.

MyKavo fixes that. It watches the pages that matter on your site and tells you when something important changes or breaks. This plugin brings that monitoring into WordPress, and adds **Safe Updates**: every time WordPress updates anything, MyKavo checks your pages straight away and tells you whether the update broke something - and exactly which update it was.

= Safe Updates =

* **Every update is checked.** Plugins, themes, WordPress itself and translations, whether you clicked Update or WordPress did it automatically.
* **Every plugin switch too.** Activating or deactivating a plugin, or switching theme, breaks sites as often as updates do. Those are checked the same way.
* **A clear verdict.** "Verified - nothing changed", or "3 changes found after this update", with the before-and-after evidence one click away.
* **The culprit, named.** Changes found after an update say so: "Appeared after: Updated WooCommerce 8.1.0 → 8.2.0".
* **A history of every update**, with versions, kept on your site.
* **Know before you press Update.** On the Plugins screen, a plugin whose last update changed things on your site is flagged: "Last time this plugin updated, 2 things changed on your site."
* Update checks are included in the Pro and Agency plans. On the free plan, updates are still listed so you know what changed and when.

= See which AI reads your site =

ChatGPT, Claude, Perplexity and other AI systems send crawlers to read your pages before they quote or recommend them. The **AI crawlers** screen shows:

* **Who visits.** Visits from OAI-SearchBot, ChatGPT-User, GPTBot, Claude-SearchBot, Claude-User, ClaudeBot, PerplexityBot, Perplexity-User, Amazonbot, DuckAssistBot, Meta-ExternalAgent, MistralAI-User, CCBot and Bytespider, and why each one visits (AI search answers, a person asking about your page, or training).
* **Which pages AI reads most**, and visits per day for the last 30 days.
* **Errors served to AI.** Pages that answered a crawler with 404 or 5xx - pages AI cannot quote.

Crawlers are counted by the name they send in the User-Agent header. No IP addresses, no cookies and nothing about human visitors are ever recorded. You can switch counting off on that screen.

= Built for WooCommerce stores =

A broken cart or checkout loses sales every minute it stays broken. If WooCommerce is active, MyKavo shows whether your Shop, Cart, Checkout and My account pages are monitored, and adds the missing ones in one click.

= What you see in WordPress =

* **Safe Updates:** a check and a verdict after every update, with the update named.
* **One clear status.** "All clear", or exactly how many important changes need attention, at the top of the screen and as a badge in the admin menu.
* **Before-and-after screenshots.** Drag a slider across the old and new version of a page, or switch to the highlighted differences.
* **The exact values that changed.** Old and new title, meta description, robots tag, canonical URL, button text and more, side by side.
* **Severity you can trust.** Every change is ranked Critical, High, Medium, Low or Info. Ad slots and other noise are filtered out, so alerts mean something.
* **One-click decisions.** Accept an intentional change as the new baseline, mark it fixed, or ignore it.
* **Run a scan on demand.** Check the site right after an update and watch the progress live.
* **Uptime, response time and SSL expiry** at a glance.
* **Scan history and monitored pages**, with a link to each page.
* **A small Dashboard widget** with the current status.
* **Monitor any page from WordPress.** A "Monitor with MyKavo" link under every published page and post, or paste an address on the Pages tab.
* **Site Health.** MyKavo's status appears in Tools > Site Health, and its details in the Info tab for support requests.
* **WP-CLI.** `wp mykavo status`, `wp mykavo changes`, `wp mykavo scan --wait`, `wp mykavo monitor`, `wp mykavo updates` and more, for scripted maintenance runs.

= What MyKavo detects =

* Pages that go down or return errors (404, 500)
* Visual changes, measured against an approved baseline
* SEO changes: title, meta description, canonical, robots / noindex, headings, structured data
* Broken internal links
* Tracking and third-party scripts added or removed (Google Analytics, Tag Manager, Meta Pixel and others)
* Performance regressions: page weight, request count, response time
* Missing or changed buttons and forms you choose to watch (conversion elements)

= Built to never slow your site down =

Many plugins get deleted because they make a site slower. MyKavo is built so that cannot happen:

* **Nothing on the public site.** No scripts, no styles, no database queries and no remote requests on the pages your visitors load. The only thing that runs is one text match on the User-Agent header to spot AI crawlers; human visitors stop there.
* **AI crawler counting is one counter update.** A request from an AI crawler adds one row update to a small table, after the page has been built. Rows older than 35 days are deleted.
* **No autoloaded options.** The connection is stored in a single option that WordPress only reads on MyKavo's own screens.
* **One small daily job.** Once a day, WP-Cron sends the AI crawler totals to MyKavo. The scanning itself runs on MyKavo's servers, not yours.
* **Admin screens only.** Scripts load on the MyKavo screen alone (plus a 2 KB script for the Dashboard widget), using only libraries WordPress already includes.
* **Update checks cost nothing extra.** The plugin notes versions while WordPress is updating, then sends one short report when the update finishes. Nothing runs between updates.
* **Cached and time-limited.** Answers from MyKavo are cached for a minute, and every request has a short timeout.

= Secure by design =

* Connecting uses an OAuth-style approval with PKCE. You approve on mykavo.app, and your site receives a key that only works for this one website.
* The key stays on your server. Your browser never sees it.
* Only administrators can see or act on monitoring.
* Disconnect at any time, from WordPress or from your MyKavo account.

= Plans =

MyKavo has a free plan: 1 website, 5 monitored pages and weekly scans, with no card required. Paid plans add daily scans, more websites and pages, manual scans and more. See [mykavo.app/pricing](https://mykavo.app/pricing).

== External services ==

This plugin connects your site to MyKavo (https://mykavo.app), a website monitoring service operated by MyKavo. It does not work without a MyKavo account.

**What is sent, and when:**

* **When you press "Connect to MyKavo":** your browser is sent to mykavo.app with your site's address, its name, its WordPress admin address, the plugin and WordPress version numbers, and one-time security values for the connection. Your site's server then sends a one-time code and your site's address to mykavo.app to finish connecting.
* **After WordPress updates plugins, themes, translations or itself, and after a plugin is activated or deactivated or the theme is switched:** your site's server sends the names and version numbers of what changed, and whether the update was automatic, so MyKavo can check the site. You can switch this off on the Safe Updates screen.
* **When you add a page to monitoring** (the "Monitor with MyKavo" link, the Pages tab, the store guard or WP-CLI): the page's address and title.
* **While an administrator views a MyKavo screen or runs a `wp mykavo` command:** your site's server requests this website's monitoring data from mykavo.app, and sends the actions you take (for example "approve this change" or "run a scan").
* **Screenshots** of your pages are loaded by the administrator's browser directly from mykavo.app, using links that expire after 30 minutes.
* **Once a day, while connected (WP-Cron):** the AI crawler totals for the last 14 days - for each day and crawler name, the number of visits, how many got an error, and the paths of the 10 most-visited pages. No IP addresses or visitor data. You can switch this off on the AI crawlers screen.
* **When you disconnect:** your site tells mykavo.app to revoke its key.

Nothing is sent when visitors view your site, and nothing about your human visitors is ever recorded or sent. MyKavo scans your public pages from its own servers, the same way a visitor would.

* Terms of service: https://mykavo.app/terms
* Privacy policy: https://mykavo.app/privacy

== Installation ==

1. Install and activate the plugin.
2. Open **MyKavo** in the admin menu and press **Connect to MyKavo**.
3. Sign in to MyKavo (or create a free account), choose which MyKavo website this site is, and approve.
4. You are back in WordPress with your site's monitoring on screen.

If your site isn't in MyKavo yet, the approval screen offers to add it first; it takes about a minute.

== Frequently Asked Questions ==

= Will this slow down my website? =

No. The plugin adds no scripts, styles, queries or remote requests to the pages your visitors load. The only public-side work is a text match on the User-Agent header; when the visitor is an AI crawler, one counter is updated after the page is built. Everything else runs inside wp-admin, and the scanning happens on MyKavo's servers.

= Why does it count AI crawlers? =

AI search is a growing way people find websites. If ChatGPT, Claude or Perplexity never read your pages, they cannot cite them. The AI crawlers screen shows which ones do, which pages they read, and which pages give them errors. It records crawler names only - never IP addresses or anything about people - and you can switch it off.

= Do I need a MyKavo account? =

Yes. The plugin shows the monitoring MyKavo does for your site. The free plan covers one website with five pages, with no card required.

= Who can see the MyKavo screen? =

Administrators only (users who can manage options).

= What happens if I disconnect or delete the plugin? =

Disconnecting revokes this site's key. Deleting the plugin removes everything it stored. Monitoring in your MyKavo account is not affected, and you can connect again at any time.

= How do Safe Updates work? =

When WordPress finishes updating anything, the plugin tells MyKavo what changed (for example "WooCommerce 8.1.0 → 8.2.0"). MyKavo scans your monitored pages against your approved baseline and reports back: nothing changed, or exactly what did. It works for automatic background updates too.

= Do Safe Updates slow down updates? =

No. The plugin reads version numbers while WordPress is already updating, and sends one small report at the end of the request. The scan itself runs on MyKavo's servers.

= Can I use it from the command line? =

Yes. With WP-CLI: `wp mykavo status` shows the site's status, `wp mykavo changes` lists changes, and `wp plugin update --all && wp mykavo scan --wait` updates everything and then waits for MyKavo's verdict, exiting with an error if something important changed. Run `wp help mykavo` for every command.

= Does it check after I activate or deactivate a plugin? =

Yes. Switching a plugin on or off, or changing the theme, is checked the same way as an update, and named in the result: "Deactivated WP Rocket - 2 changes found".

= Can I connect several WordPress sites? =

Yes. Install the plugin on each site and connect each one to its own website in MyKavo.

= My site is behind a firewall. Will it work? =

Your server needs to be able to make outbound HTTPS requests to mykavo.app, which almost every host allows. MyKavo also needs to be able to reach your public pages to scan them.

== Screenshots ==

1. Overview: one clear status, uptime and SSL, what needs attention first, and the latest update check.
2. Safe Updates: every update, plugin switch and theme change, with a verdict and the change named.
3. A change that appeared after an update, with the update named.
4. A change, with a before-and-after slider over the page screenshots.
5. Exactly what changed: old and new values side by side.
6. All changes, filtered by status and severity.
7. Scan history.
8. Connect in two clicks. Nothing is added to your public pages.
9. WooCommerce store guard: see which store pages are monitored and add the rest in one click.

== Changelog ==

= 1.1.0 =
* New: AI crawlers screen - which AI systems (ChatGPT, Claude, Perplexity and more) read your site, which pages they read most, visits per day, and errors served to them. Also shown in your MyKavo dashboard.
* Crawler names only: no IP addresses, cookies or visitor data. Can be switched off.

= 1.0.0 =
* First release.
* Safe Updates: a check after every plugin, theme, WordPress and translation update (automatic updates included), and after plugins are activated or deactivated or the theme is switched, with the change named on everything it found.
* Overview with one clear status, uptime, response time and SSL expiry.
* Changes with before-and-after screenshots, exact old and new values, and one-click approve, fixed, ignore or accept as new baseline.
* On-demand scans with live progress, scan history and monitored pages.
* WooCommerce store guard for Shop, Cart, Checkout and My account.
* "Monitor with MyKavo" under every published page and post.
* A warning on the Plugins screen for a plugin whose last update changed your site.
* Site Health test and Info section, admin menu badge and Dashboard widget.
* WP-CLI commands: `wp mykavo status`, `changes`, `scan --wait`, `monitor`, `updates`, `safe-updates` and `disconnect`.
* Suggested privacy policy text.

== Upgrade Notice ==

= 1.1.0 =
See which AI systems read your site: the new AI crawlers screen.

= 1.0.0 =
First release.
